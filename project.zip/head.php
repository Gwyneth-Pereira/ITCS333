	<!-- FAVICON  -->
    <link rel="shortcut icon" href="images/favicon.png">

    <!-- CSS -->
	<link rel="stylesheet" type="text/css" href="css/aos.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-grid.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.css">
	<link rel="stylesheet" type="text/css" href="css/custom.css">

	<!-- GOOGLE FONT -->
    <link rel='stylesheet' type='text/css' href='http://fonts.googleapis.com/css?family=Montserrat:400,500,600,700'>